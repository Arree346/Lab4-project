
-- إنشاء قاعدة بيانات
CREATE DATABASE tvtc;

-- استخدام قاعدة البيانات
USE tvtc;

-- إنشاء جدول الأقسام
CREATE TABLE dep (
  depno INT PRIMARY KEY,
  depname VARCHAR(20)
);

-- إنشاء جدول الطلاب
CREATE TABLE std (
  stdno INT PRIMARY KEY,
  stdname VARCHAR(20),
  depno INT,
  FOREIGN KEY (depno) REFERENCES dep(depno)
);

-- حذف الجداول (في حالة التراجع)
DROP TABLE dep;
DROP TABLE std;

-- تعديل جدول dep
ALTER TABLE dep ADD loc VARCHAR(20);
ALTER TABLE dep DROP COLUMN loc;
ALTER TABLE dep MODIFY depname NVARCHAR(30);
