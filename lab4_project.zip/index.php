<?php
echo "<h1>Welcome to Lab4 Project!</h1>";
echo "<p>This is a simple PHP file for testing the project setup.</p>";
?>